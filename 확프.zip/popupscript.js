function nick(a) {
    window.document.getElementsByTagName('iframe')[0].contentWindow.user.nickname = a
}

function user(a) {
    window.document.getElementsByTagName('iframe')[0].contentWindow.user.username = a
}

function objl() {
    console.log("[오브젝트 리스트 출력 결과]")
    console.log(window.document.getElementsByTagName('iframe')[0].contentWindow.Entry.container.objects_)
    console.log(`\n`)
}

function objx(a, b) {
    window.document.getElementsByTagName('iframe')[parseInt(a)].contentWindow.Entry.container.objects_[0].entity.x = parseInt(b)
}

function objy(a, b) {
    window.document.getElementsByTagName('iframe')[parseInt(a)].contentWindow.Entry.container.objects_[0].entity.y = parseInt(b)
}

function senc() {
    Entry.scene.updateView=function(Ỿ,ꝍ){this.prevButton_.removeClass`entryRemove`;this.nextButton_.removeClass`entryRemove`;this.nextAddButton_.removeClass`entryRemove`;this.updateSceneView();this.resize()};Entry.scene.updateView()
}

function list(a, b, c) {
    window.document.getElementsByTagName('iframe')[0].contentWindow.Entry.variableContainer.getListByName(a).insertValue(parseInt(b), c)
}

function fltm(a, b, c) {
    window.document.getElementsByTagName('iframe')[0].contentWindow.Entry.variableContainer.getListByName(a).replaceValue(parseInt(b), c);
}

function varq(a, b) {
    window.document.getElementsByTagName('iframe')[0].contentWindow.Entry.variableContainer.getVariableByName(a).setValue(b)
}

function loop() {
    Entry.isTurbo = true
}

function qksq() {
    window.document.getElementsByTagName('iframe')[0].contentWindow.Entry.isTurbo = true
}

function wprj(a, b) {
    window.document.getElementsByTagName('iframe')[0].contentWindow.Entry.variableContainer.getListByName(a).deleteValue(b)
}

////////////////////////////////////////////////////////
////////////////////////////////////////////////////////

function nickname() {
    chrome.tabs.query({active: true, lastFocusedWindow: true}, function(tabs) {
        var tab = tabs[0];
        chrome.scripting.executeScript({
            target : {tabId : tab.id},
            func: nick,
            args: [document.getElementById("nick1").value],
            world: 'MAIN',
        })
    });
    document.getElementById("nick").style.display = "block"
    document.getElementById("nickname").style.display = "none"
    setTimeout(function(){
        document.getElementById("nick").style.display = "none"
        document.getElementById("nickname").style.display = "block"
    }, 1000);
}
////////////////////////////////////////////////////////
function username() {
    chrome.tabs.query({active: true, lastFocusedWindow: true}, function(tabs) {
        var tab = tabs[0];
        chrome.scripting.executeScript({
            target : {tabId : tab.id},
            func: user,
            args: [document.getElementById("user1").value],
            world: 'MAIN',
        })
    });
    document.getElementById("user").style.display = "block"
    document.getElementById("username").style.display = "none"
    setTimeout(function(){
        document.getElementById("user").style.display = "none"
        document.getElementById("username").style.display = "block"
    }, 1000);
}
////////////////////////////////////////////////////////
function korean() {
    document.getElementById("kore1").value = document.getElementById("kore1").value.normalize("NFD")
    document.getElementById("kore").style.display = "block"
    document.getElementById("korean").style.display = "none"
    document.getElementById("kore1").style.color = "lime"
    setTimeout(function(){
        document.getElementById("kore").style.display = "none"
        document.getElementById("korean").style.display = "block"
    }, 1000);
}
////////////////////////////////////////////////////////
function objlist() {
    chrome.tabs.query({active: true, lastFocusedWindow: true}, function(tabs) {
        var tab = tabs[0];
        chrome.scripting.executeScript({
            target : {tabId : tab.id},
            func: objl,
            world: 'MAIN',
        })
    });
    document.getElementById("objl").style.display = "block"
    document.getElementById("objlist").style.display = "none"
    setTimeout(function(){
        document.getElementById("objl").style.display = "none"
        document.getElementById("objlist").style.display = "block"
    }, 1000);
}
////////////////////////////////////////////////////////
function objxpos() {
    chrome.tabs.query({active: true, lastFocusedWindow: true}, function(tabs) {
        var tab = tabs[0];
        chrome.scripting.executeScript({
            target : {tabId : tab.id},
            func: objx,
            args: [document.getElementById("objx1").value, document.getElementById("objx2").value],
            world: 'MAIN',
        })
    });
    document.getElementById("objx").style.display = "block"
    document.getElementById("objxpos").style.display = "none"
    setTimeout(function(){
        document.getElementById("objx").style.display = "none"
        document.getElementById("objxpos").style.display = "block"
    }, 1000);
}
////////////////////////////////////////////////////////
function objypos() {
    chrome.tabs.query({active: true, lastFocusedWindow: true}, function(tabs) {
        var tab = tabs[0];
        chrome.scripting.executeScript({
            target : {tabId : tab.id},
            func: objy,
            args: [document.getElementById("objy1").value, document.getElementById("objy2").value],
            world: 'MAIN',
        })
    });
    document.getElementById("objy").style.display = "block"
    document.getElementById("objypos").style.display = "none"
    setTimeout(function(){
        document.getElementById("objy").style.display = "none"
        document.getElementById("objypos").style.display = "block"
    }, 1000);
}
////////////////////////////////////////////////////////
function senceinf() {
    chrome.tabs.query({active: true, lastFocusedWindow: true}, function(tabs) {
        var tab = tabs[0];
        chrome.scripting.executeScript({
            target : {tabId : tab.id},
            func: senc,
            world: 'MAIN',
        })
    });
    document.getElementById("senc").style.display = "block"
    document.getElementById("senceinf").style.display = "none"
    setTimeout(function(){
        document.getElementById("senc").style.display = "none"
        document.getElementById("senceinf").style.display = "block"
    }, 1000);
}
////////////////////////////////////////////////////////
function listRLdnrl() {
    chrome.tabs.query({active: true, lastFocusedWindow: true}, function(tabs) {
        var tab = tabs[0];
        chrome.scripting.executeScript({
            target : {tabId : tab.id},
            func: list,
            args: [document.getElementById("list1").value, document.getElementById("list2").value, document.getElementById("list3").value, ],
            world: 'MAIN',
        })
    });
    document.getElementById("list").style.display = "block"
    document.getElementById("listRLdnrl").style.display = "none"
    setTimeout(function(){
        document.getElementById("list").style.display = "none"
        document.getElementById("listRLdnrl").style.display = "block"
    }, 1000);
}
////////////////////////////////////////////////////////
function fltmxmqusrud() {
    chrome.tabs.query({active: true, lastFocusedWindow: true}, function(tabs) {
        var tab = tabs[0];
        chrome.scripting.executeScript({
            target : {tabId : tab.id},
            func: fltm,
            args: [document.getElementById("fltm1").value, document.getElementById("fltm2").value, document.getElementById("fltm3").value, ],
            world: 'MAIN',
        })
    });
    document
    document.getElementById("fltm").style.display = "block"
    document.getElementById("fltmxmqusrud").style.display = "none"
    setTimeout(function(){
        document.getElementById("fltm").style.display = "none"
        document.getElementById("fltmxmqusrud").style.display = "block"
    }, 1000);
}
////////////////////////////////////////////////////////
function varqusrud() {
    chrome.tabs.query({active: true, lastFocusedWindow: true}, function(tabs) {
        var tab = tabs[0];
        chrome.scripting.executeScript({
            target : {tabId : tab.id},
            func: varq,
            args: [document.getElementById("varq1").value, document.getElementById("varq2").value, ],
            world: 'MAIN',
        })
    });
    document.getElementById("varq").style.display = "block"
    document.getElementById("varqusrud").style.display = "none"
    setTimeout(function(){
        document.getElementById("varq").style.display = "none"
        document.getElementById("varqusrud").style.display = "block"
    }, 1000);
}
////////////////////////////////////////////////////////
function looplimit() {
    chrome.tabs.query({active: true, lastFocusedWindow: true}, function(tabs) {
        var tab = tabs[0];
        chrome.scripting.executeScript({
            target : {tabId : tab.id},
            func: loop,
            world: 'MAIN',
        })
    });
    document.getElementById("loop").style.display = "block"
    document.getElementById("looplimit").style.display = "none"
    setTimeout(function(){
        document.getElementById("loop").style.display = "none"
        document.getElementById("looplimit").style.display = "block"
    }, 1000);
}
////////////////////////////////////////////////////////
function qksqhranslimit() {
    chrome.tabs.query({active: true, lastFocusedWindow: true}, function(tabs) {
        var tab = tabs[0];
        chrome.scripting.executeScript({
            target : {tabId : tab.id},
            func: qksq,
            world: 'MAIN',
        })
    });
    document.getElementById("qksq").style.display = "block"
    document.getElementById("qksqhranslimit").style.display = "none"
    setTimeout(function(){
        document.getElementById("qksq").style.display = "none"
        document.getElementById("qksqhranslimit").style.display = "block"
    }, 1000);
}
////////////////////////////////////////////////////////
function wprjfltmxm() {
    chrome.tabs.query({active: true, lastFocusedWindow: true}, function(tabs) {
        var tab = tabs[0];
        chrome.scripting.executeScript({
            target : {tabId : tab.id},
            func: wprj,
            args: [document.getElementById("wprj1").value, document.getElementById("wprj2").value, ],
            world: 'MAIN',
        })
    });
    document.getElementById("qksq").style.display = "block"
    document.getElementById("qksqhranslimit").style.display = "none"
    setTimeout(function(){
        document.getElementById("qksq").style.display = "none"
        document.getElementById("qksqhranslimit").style.display = "block"
    }, 1000);
}
////////////////////////////////////////////////////////
document.getElementById("nickname").addEventListener("click", nickname)
document.getElementById("username").addEventListener("click", username)
document.getElementById("korean").addEventListener("click", korean)
document.getElementById("objlist").addEventListener("click", objlist)
document.getElementById("objxpos").addEventListener("click", objxpos)
document.getElementById("objypos").addEventListener("click", objypos)
document.getElementById("senceinf").addEventListener("click", senceinf)
document.getElementById("listRLdnrl").addEventListener("click", listRLdnrl)
document.getElementById("fltmxmqusrud").addEventListener("click", fltmxmqusrud)
document.getElementById("varqusrud").addEventListener("click", varqusrud)
document.getElementById("qksqhranslimit").addEventListener("click", qksqhranslimit)
document.getElementById("looplimit").addEventListener("click", looplimit)
document.getElementById("wprjfltmxm").addEventListener("click", wprjfltmxm)
document.getElementById("nick1").addEventListener('keyup', event => {if (event.key === 'Enter') {nickname(); }})
document.getElementById("user1").addEventListener('keyup', event => {if (event.key === 'Enter') {username(); }})
document.getElementById("kore1").addEventListener('keyup', event => {if (event.key === 'Enter') {korean(); }})
document.getElementById("objx1").addEventListener('keyup', event => {if (event.key === 'Enter') {objxpos(); }})
document.getElementById("objx2").addEventListener('keyup', event => {if (event.key === 'Enter') {objxpos(); }})
document.getElementById("objy1").addEventListener('keyup', event => {if (event.key === 'Enter') {objxpos(); }})
document.getElementById("objy2").addEventListener('keyup', event => {if (event.key === 'Enter') {objxpos(); }})
document.getElementById("list1").addEventListener('keyup', event => {if (event.key === 'Enter') {listRLdnrl(); }})
document.getElementById("list2").addEventListener('keyup', event => {if (event.key === 'Enter') {listRLdnrl(); }})
document.getElementById("list3").addEventListener('keyup', event => {if (event.key === 'Enter') {listRLdnrl(); }})
document.getElementById("fltm1").addEventListener('keyup', event => {if (event.key === 'Enter') {fltmxmqusrud(); }})
document.getElementById("fltm2").addEventListener('keyup', event => {if (event.key === 'Enter') {fltmxmqusrud(); }})
document.getElementById("fltm3").addEventListener('keyup', event => {if (event.key === 'Enter') {fltmxmqusrud(); }})
document.getElementById("varq1").addEventListener('keyup', event => {if (event.key === 'Enter') {varqusrud(); }})
document.getElementById("varq2").addEventListener('keyup', event => {if (event.key === 'Enter') {varqusrud(); }})
document.getElementById("wprj1").addEventListener('keyup', event => {if (event.key === 'Enter') {wprjfltmxm(); }})
document.getElementById("wprj2").addEventListener('keyup', event => {if (event.key === 'Enter') {wprjfltmxm(); }})
document.getElementById("kore1").addEventListener('keydown', event =>  document.getElementById("kore1").style.color = "#fff" )